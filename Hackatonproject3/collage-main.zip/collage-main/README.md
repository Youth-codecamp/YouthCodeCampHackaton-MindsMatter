# collage
collage or school website design by gaurav tripathi

using html css and javascripy

live link
https://gauravias.github.io/collage/
